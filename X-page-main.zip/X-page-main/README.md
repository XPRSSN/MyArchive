# X-page

Simple search page
