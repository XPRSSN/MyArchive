### Python Classes

```markdown
This is a repository for me
to keep my python class files

While it is completely useless
for you, nobody is preventing you
from snooping around so you can take
a look and even help if you want

```

Keep in mind that some files may not be completed
